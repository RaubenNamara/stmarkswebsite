<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
{
    Schema::create('mentorships', function (Blueprint $table) {
        $table->id();
        $table->string('title');
        $table->text('caption')->nullable();
        $table->longText('description')->nullable();
        $table->string('image')->nullable();
        $table->string('video')->nullable();
        $table->string('video_link')->nullable();
        $table->timestamps();
    });
}

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('mentorships');
    }
};
