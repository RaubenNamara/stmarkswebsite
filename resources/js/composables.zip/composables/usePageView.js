import { onMounted } from 'vue'

export function usePageView(pageType = null, pageId = null) {
  function trackPageView() {
    const pageUrl = window.location.href

    fetch('/api/page-view', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.content,
      },
      body: JSON.stringify({
        page_url: pageUrl,
        page_type: pageType,
        page_id: pageId,
      }),
    }).catch((error) => {
      console.error('Failed to track page view:', error)
    })
  }

  onMounted(() => {
    trackPageView()
  })

  return {
    trackPageView,
  }
}
