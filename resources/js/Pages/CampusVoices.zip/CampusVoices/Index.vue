<script setup>
import MainLayout from '@/Layouts/MainLayout.vue'
import { Head, usePage, router } from '@inertiajs/vue3'
import { ref, computed, watch } from 'vue'
import HeroArticle from '@/Components/CampusVoices/HeroArticle.vue'
import ArticleCard from '@/Components/CampusVoices/ArticleCard.vue'
import Sidebar from '@/Components/CampusVoices/Sidebar.vue'

defineOptions({ layout: MainLayout })

const page = usePage()
const articles = ref(page.props.articles || [])
const featuredArticle = ref(page.props.featuredArticle || null)
const categories = ref(page.props.categories || [])
const recentArticles = ref(page.props.recentArticles || [])
const mostViewed = ref(page.props.mostViewed || [])
const searchQuery = ref(page.props.search || '')
let searchTimeout = null

/*
|--------------------------------------------------------------------------
| SEARCH
|--------------------------------------------------------------------------
*/
function performSearch() {
  router.get(route('explore.campus-voices'), { search: searchQuery.value }, {
    preserveState: true,
    preserveScroll: true,
  })
}

function clearSearch() {
  searchQuery.value = ''
  performSearch()
}

// Real-time search with debounce
watch(searchQuery, (newValue) => {
  if (searchTimeout) {
    clearTimeout(searchTimeout)
  }
  searchTimeout = setTimeout(() => {
    performSearch()
  }, 500)
})

/*
|--------------------------------------------------------------------------
| GRID LAYOUT
|--------------------------------------------------------------------------
*/
const gridCols = computed(() =>
  'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6 lg:gap-6 xl:gap-8'
)
</script>

<template>
  <Head title="Campus Voices" />

  <div class="min-h-screen bg-gray-50">
    
    <!-- ================= HERO SECTION ================= -->
    <HeroArticle v-if="featuredArticle" :article="featuredArticle" />

    <!-- ================= MAIN CONTENT ================= -->
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 xl:px-12 2xl:px-16 py-12">
      
      <div class="flex flex-col lg:flex-row gap-6 lg:gap-8 xl:gap-10">
        
        <!-- Main Content Area -->
        <div class="flex-1">
          
          <!-- Page Title & Search -->
          <div class="mb-8">
            <h1 class="text-4xl font-bold text-gray-900 mb-6">Campus Voices</h1>
            
            <!-- Search Bar -->
            <div class="max-w-md">
              <div class="relative">
                <input
                  v-model="searchQuery"
                  type="text"
                  placeholder="Search by student name..."
                  class="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gray-500 focus:border-transparent"
                  @keyup.enter="performSearch"
                />
                <svg
                  class="absolute left-3 top-3.5 h-5 w-5 text-gray-400"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    stroke-width="2"
                    d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                  />
                </svg>
                <button
                  v-if="searchQuery"
                  @click="clearSearch"
                  class="absolute right-3 top-3.5 text-gray-400 hover:text-gray-600"
                >
                  <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
              <button
                @click="performSearch"
                class="mt-2 bg-gray-900 text-white px-4 py-2 rounded-lg hover:bg-gray-800 transition"
              >
                Search
              </button>
            </div>
          </div>

          <!-- No Results -->
          <div v-if="articles.length === 0" class="text-center py-12">
            <p class="text-xl text-gray-600">
              {{ searchQuery ? 'No articles found matching your search.' : 'No Campus Voices articles yet.' }}
            </p>
          </div>

          <!-- Articles Grid -->
          <div v-else :class="gridCols">
            <ArticleCard
              v-for="article in articles"
              :key="article.id"
              :article="article"
            />
          </div>

        </div>

        <!-- Sidebar -->
        <div class="lg:w-80">
          <Sidebar
            :categories="categories"
            :recent-articles="recentArticles"
            :most-viewed="mostViewed"
          />
        </div>

      </div>

    </div>

  </div>
</template>

<style scoped>
.line-clamp-2 {
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.line-clamp-3 {
  display: -webkit-box;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
</style>
