<script setup>
import AdminLayout from '@/Layouts/AdminLayout.vue'
import { Head, useForm } from '@inertiajs/vue3'
import { ref } from 'vue'
import Editor from '@tinymce/tinymce-vue'

defineOptions({ layout: AdminLayout })

const props = defineProps({
  campusVoice: Object
})

const form = useForm({
  student_name: props.campusVoice.student_name,
  title: props.campusVoice.title,
  slug: props.campusVoice.slug,
  summary: props.campusVoice.summary,
  content: props.campusVoice.content,
  featured_image: null,
  category: props.campusVoice.category,
  author: props.campusVoice.author,
  featured: props.campusVoice.featured,
  status: props.campusVoice.status,
})

const preview = ref(props.campusVoice.image_url)

const tinyMceConfig = {
  height: 400,
  menubar: true,
  plugins: [
    'advlist', 'autolink', 'lists', 'link', 'image', 'charmap', 'preview',
    'anchor', 'searchreplace', 'visualblocks', 'code', 'fullscreen',
    'insertdatetime', 'media', 'table', 'help', 'wordcount'
  ],
  toolbar: 'undo redo | blocks | ' +
    'bold italic forecolor | alignleft aligncenter ' +
    'alignright alignjustify | bullist numlist outdent indent | ' +
    'removeformat | help',
  content_style: 'body { font-family:Helvetica,Arial,sans-serif; font-size:14px }'
}

/*
|--------------------------------------------------------------------------
| IMAGE COMPRESSION FUNCTION
|--------------------------------------------------------------------------
*/
async function compressImage(file) {
  return new Promise((resolve) => {
    const img = new Image()
    const reader = new FileReader()

    reader.onload = (e) => {
      img.src = e.target.result
    }

    img.onload = () => {
      const canvas = document.createElement('canvas')

      const MAX_WIDTH = 1200
      const scale = MAX_WIDTH / img.width

      canvas.width = MAX_WIDTH
      canvas.height = img.height * scale

      const ctx = canvas.getContext('2d')
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height)

      canvas.toBlob((blob) => {
        resolve(new File([blob], file.name, {
          type: 'image/jpeg',
          lastModified: Date.now()
        }))
      }, 'image/jpeg', 0.7)
    }

    img.onerror = () => resolve(file)

    reader.readAsDataURL(file)
  })
}

/*
|--------------------------------------------------------------------------
| HANDLE FILE (COMPRESSED)
|--------------------------------------------------------------------------
*/
async function handleFile(e) {
  const file = e.target.files?.[0]

  if (!file) {
    form.featured_image = null
    preview.value = props.campusVoice.image_url
    return
  }

  const compressed = await compressImage(file)

  form.featured_image = compressed
  preview.value = URL.createObjectURL(compressed)
}

/*
|--------------------------------------------------------------------------
| AUTO SUMMARY
|--------------------------------------------------------------------------
*/
function generateSummary() {
  if (!form.content) return ''
  const text = form.content.replace(/<[^>]*>/g, '')
  return text.substring(0, 200) + '...'
}

/*
|--------------------------------------------------------------------------
| SUBMIT
|--------------------------------------------------------------------------
*/
function submit() {
  if (!form.summary) {
    form.summary = generateSummary()
  }

  form.put(route('admin.campus-voices.update', props.campusVoice.id), {
    forceFormData: true,
    onSuccess: () => {
      form.featured_image = null
    }
  })
}
</script>

<template>
  <Head :title="'Edit Campus Voice - ' + campusVoice.title" />

  <div class="p-8 space-y-8">

    <!-- ================= HEADER ================= -->
    <div class="flex items-center justify-between">
      <h1 class="text-3xl font-bold text-gray-800">Edit Campus Voice Article</h1>
      <a
        :href="route('admin.campus-voices.index')"
        class="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-lg font-medium transition"
      >
        Back to List
      </a>
    </div>

    <!-- ================= EDIT FORM ================= -->
    <div class="bg-white rounded-lg shadow p-6">
      <form @submit.prevent="submit" class="space-y-6">

        <!-- STUDENT NAME -->
        <div>
          <label class="block text-sm font-medium mb-1">Student Name *</label>
          <input
            v-model="form.student_name"
            type="text"
            class="w-full border p-2 rounded"
            required
          />
          <p v-if="form.errors.student_name" class="text-red-600 text-sm mt-1">
            {{ form.errors.student_name }}
          </p>
        </div>

        <!-- TITLE -->
        <div>
          <label class="block text-sm font-medium mb-1">Title *</label>
          <input
            v-model="form.title"
            type="text"
            class="w-full border p-2 rounded"
            required
          />
          <p v-if="form.errors.title" class="text-red-600 text-sm mt-1">
            {{ form.errors.title }}
          </p>
        </div>

        <!-- SLUG -->
        <div>
          <label class="block text-sm font-medium mb-1">Slug</label>
          <input
            v-model="form.slug"
            type="text"
            class="w-full border p-2 rounded"
          />
          <p v-if="form.errors.slug" class="text-red-600 text-sm mt-1">
            {{ form.errors.slug }}
          </p>
        </div>

        <!-- CATEGORY -->
        <div>
          <label class="block text-sm font-medium mb-1">Category</label>
          <input
            v-model="form.category"
            type="text"
            class="w-full border p-2 rounded"
            placeholder="e.g., Achievement, Interview, Opinion"
          />
          <p v-if="form.errors.category" class="text-red-600 text-sm mt-1">
            {{ form.errors.category }}
          </p>
        </div>

        <!-- AUTHOR -->
        <div>
          <label class="block text-sm font-medium mb-1">Author</label>
          <input
            v-model="form.author"
            type="text"
            class="w-full border p-2 rounded"
            placeholder="Author name"
          />
          <p v-if="form.errors.author" class="text-red-600 text-sm mt-1">
            {{ form.errors.author }}
          </p>
        </div>

        <!-- SUMMARY -->
        <div>
          <label class="block text-sm font-medium mb-1">Summary</label>
          <textarea
            v-model="form.summary"
            rows="3"
            class="w-full border p-2 rounded"
            placeholder="Brief summary"
          ></textarea>
          <p v-if="form.errors.summary" class="text-red-600 text-sm mt-1">
            {{ form.errors.summary }}
          </p>
        </div>

        <!-- CONTENT -->
        <div>
          <label class="block text-sm font-medium mb-1">Content *</label>
          <Editor
            v-model="form.content"
            :init="tinyMceConfig"
            api-key="ve0oi3p5g5lensb034xuxzva1td9saq5mw68wpf2u0666ae0"
            :disabled="form.processing"
          />
          <p v-if="form.errors.content" class="text-red-600 text-sm mt-1">
            {{ form.errors.content }}
          </p>
        </div>

        <!-- FEATURED IMAGE -->
        <div>
          <label class="block text-sm font-medium mb-1">Featured Image</label>
          <input
            type="file"
            accept="image/*"
            @change="handleFile"
            class="w-full border p-2 rounded"
          />
          <p v-if="form.errors.featured_image" class="text-red-600 text-sm mt-1">
            {{ form.errors.featured_image }}
          </p>

          <img
            v-if="preview"
            :src="preview"
            class="mt-3 h-48 w-full object-cover rounded"
          />
        </div>

        <!-- FEATURED -->
        <div class="flex items-center gap-2">
          <input
            type="checkbox"
            v-model="form.featured"
            id="featured"
            class="w-4 h-4"
          />
          <label for="featured" class="text-sm font-medium">
            Mark as Featured Article
          </label>
        </div>

        <!-- STATUS -->
        <div>
          <label class="block text-sm font-medium mb-1">Status *</label>
          <select
            v-model="form.status"
            class="w-full border p-2 rounded"
            required
          >
            <option value="draft">Draft</option>
            <option value="published">Published</option>
          </select>
          <p v-if="form.errors.status" class="text-red-600 text-sm mt-1">
            {{ form.errors.status }}
          </p>
        </div>

        <!-- VIEW COUNT (READ ONLY) -->
        <div>
          <label class="block text-sm font-medium mb-1">View Count</label>
          <input
            :value="campusVoice.views"
            type="text"
            class="w-full border p-2 rounded bg-gray-100"
            readonly
          />
        </div>

        <!-- BUTTONS -->
        <div class="flex gap-4">
          <button
            type="submit"
            :disabled="form.processing"
            class="bg-blue-900 text-white px-6 py-2 rounded disabled:opacity-50"
          >
            {{ form.processing ? 'Updating...' : 'Update Article' }}
          </button>

          <a
            :href="route('admin.campus-voices.index')"
            class="bg-gray-200 text-gray-700 px-6 py-2 rounded"
          >
            Cancel
          </a>
        </div>

      </form>
    </div>

  </div>
</template>
