<script setup>
import { Link } from '@inertiajs/vue3'

const props = defineProps({
  article: {
    type: Object,
    required: true
  }
})
</script>

<template>
  <div v-if="article" class="bg-gradient-to-r from-gray-800 to-gray-700 text-white">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 xl:px-12 2xl:px-16 py-12 lg:py-16 xl:py-20">
      <div class="flex flex-col lg:flex-row items-center gap-6 lg:gap-8 xl:gap-10">
        
        <!-- Image -->
        <div class="w-full lg:w-1/2 flex items-center justify-center">
          <img
            v-if="article.image_url"
            :src="article.image_url"
            class="w-full h-48 sm:h-64 lg:h-80 xl:h-96 2xl:h-[28rem] object-contain rounded-lg shadow-2xl"
          />
          <div v-else class="w-full h-48 sm:h-64 lg:h-80 xl:h-96 2xl:h-[28rem] bg-gray-300 rounded-lg flex items-center justify-center">
            <span class="text-gray-500">No image</span>
          </div>
        </div>

        <!-- Content -->
        <div class="w-full lg:w-1/2 space-y-3 lg:space-y-4 xl:space-y-5">
          <span class="inline-block bg-amber-400 text-amber-900 px-3 py-1 rounded-full text-xs sm:text-sm font-bold">
            ⭐ Featured Article
          </span>
          
          <h1 class="text-2xl sm:text-3xl lg:text-4xl xl:text-5xl 2xl:text-6xl font-bold leading-tight">
            {{ article.title }}
          </h1>
          
          <p class="text-base sm:text-lg lg:text-xl xl:text-2xl text-gray-200">
            By <span class="font-semibold">{{ article.student_name }}</span>
          </p>
          
          <p class="text-sm sm:text-base lg:text-lg xl:text-xl text-gray-200 line-clamp-3">
            {{ article.summary }}
          </p>
          
          <div class="flex flex-wrap items-center gap-3 lg:gap-4 text-xs sm:text-sm text-gray-300">
            <span v-if="article.category" class="bg-gray-600 px-2 py-1 rounded">
              {{ article.category }}
            </span>
            <span>{{ article.published_at }}</span>
            <span>👁 {{ article.views }} views</span>
          </div>
          
          <Link
            :href="route('campus-voices.show', article.slug)"
            class="inline-block bg-white text-gray-900 px-4 sm:px-6 py-2 sm:py-3 rounded-lg text-sm sm:text-base font-semibold hover:bg-gray-100 transition transform hover:scale-105"
          >
            Read More
          </Link>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.line-clamp-3 {
  display: -webkit-box;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
  overflow: hidden;
  line-clamp: 3;
}
</style>
