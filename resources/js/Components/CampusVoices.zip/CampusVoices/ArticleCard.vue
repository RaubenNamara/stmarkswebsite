<script setup>
import { Link } from '@inertiajs/vue3'

const props = defineProps({
  article: {
    type: Object,
    required: true
  }
})
</script>

<template>
  <div class="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-xl transition-shadow duration-300 flex flex-col">
    <!-- Image -->
    <div class="h-48 bg-gray-100 relative overflow-hidden flex items-center justify-center">
      <img
        v-if="article.image_url"
        :src="article.image_url"
        class="w-full h-full object-contain hover:scale-105 transition-transform duration-300"
        loading="lazy"
      />
      <div v-else class="flex items-center justify-center h-full text-gray-400">
        No image
      </div>
    </div>

    <!-- Content -->
    <div class="p-5 flex flex-col flex-1">
      <!-- Category Badge -->
      <div class="mb-3">
        <span v-if="article.category" class="bg-gray-100 text-gray-800 px-3 py-1 rounded-full text-sm font-medium">
          {{ article.category }}
        </span>
      </div>

      <!-- Student Name -->
      <p class="text-sm text-gray-600 mb-2">
        <span class="font-semibold">{{ article.student_name }}</span>
      </p>

      <!-- Title -->
      <h3 class="text-xl font-bold text-gray-900 mb-3 line-clamp-2">
        {{ article.title }}
      </h3>

      <!-- Summary -->
      <p class="text-gray-600 mb-4 line-clamp-3 flex-1">
        {{ article.summary || 'No summary available.' }}
      </p>

      <!-- Meta -->
      <div class="flex items-center justify-between text-sm text-gray-500 mb-4">
        <span>{{ article.published_at }}</span>
        <span class="flex items-center gap-1">
          👁 {{ article.views }}
        </span>
      </div>

      <!-- Read More Button -->
      <Link
        :href="route('campus-voices.show', article.slug)"
        class="inline-block bg-gray-900 text-white px-4 py-2 rounded-lg text-center font-medium hover:bg-gray-800 transition transform hover:scale-105"
      >
        Read More
      </Link>
    </div>
  </div>
</template>

<style scoped>
.line-clamp-2 {
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
  line-clamp: 2;
}

.line-clamp-3 {
  display: -webkit-box;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
  overflow: hidden;
  line-clamp: 3;
}
</style>
